Cite as: National Geophysical Data Center (1976): The NGDC Seafloor Sediment Grain Size Database. National Geophysical Data Center, NOAA, doi:10.7289/V5G44N6W [date of access] 
 
For more information, see DOI:10.7289/V5G44N6W
